atkNoOpObject <- atkNoOpObjectNew

atkNoOpObjectFactory <- atkNoOpObjectFactoryNew

atkRelation <- atkRelationNew

atkRelationSet <- atkRelationSetNew

atkStateSet <- atkStateSetNew

