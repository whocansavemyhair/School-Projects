tree_store$insert(iter, position)
tree_store$set(iter, ...)
