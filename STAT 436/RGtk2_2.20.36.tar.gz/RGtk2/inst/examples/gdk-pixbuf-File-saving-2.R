# (R does not require NULL-terminated vararg lists)
pixbuf$save(handle, "jpeg", "quality", "100") 
