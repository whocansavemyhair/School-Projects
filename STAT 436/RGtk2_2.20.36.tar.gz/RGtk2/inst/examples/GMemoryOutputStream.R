## a stream that can grow
stream <- gMemoryOutputStream(0)

## fixed-size streams are not supported
