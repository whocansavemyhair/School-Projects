Compile-time
--------
R users should not be concerned with compile-time version checking.

Run-time
--------
cairoVersionString()	Human-readable, use compareVersion() for comparison
cairoVersion()		Encoded, not very useful in R
