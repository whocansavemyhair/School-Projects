R_RegisterCCallable("RGtk2", "S_pango_font_class_init", ((DL_FUNC)S_pango_font_class_init)); 
R_RegisterCCallable("RGtk2", "S_pango_font_face_class_init", ((DL_FUNC)S_pango_font_face_class_init)); 
R_RegisterCCallable("RGtk2", "S_pango_font_family_class_init", ((DL_FUNC)S_pango_font_family_class_init)); 
R_RegisterCCallable("RGtk2", "S_pango_font_map_class_init", ((DL_FUNC)S_pango_font_map_class_init)); 
R_RegisterCCallable("RGtk2", "S_pango_fontset_class_init", ((DL_FUNC)S_pango_fontset_class_init)); 
R_RegisterCCallable("RGtk2", "S_pango_renderer_class_init", ((DL_FUNC)S_pango_renderer_class_init)); 
