R_RegisterCCallable("RGtk2", "S_atk_hyperlink_class_init", ((DL_FUNC)S_atk_hyperlink_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_object_class_init", ((DL_FUNC)S_atk_object_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_gobject_accessible_class_init", ((DL_FUNC)S_atk_gobject_accessible_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_no_op_object_class_init", ((DL_FUNC)S_atk_no_op_object_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_object_factory_class_init", ((DL_FUNC)S_atk_object_factory_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_no_op_object_factory_class_init", ((DL_FUNC)S_atk_no_op_object_factory_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_registry_class_init", ((DL_FUNC)S_atk_registry_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_relation_class_init", ((DL_FUNC)S_atk_relation_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_relation_set_class_init", ((DL_FUNC)S_atk_relation_set_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_state_set_class_init", ((DL_FUNC)S_atk_state_set_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_util_class_init", ((DL_FUNC)S_atk_util_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_table_class_init", ((DL_FUNC)S_atk_table_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_streamable_content_class_init", ((DL_FUNC)S_atk_streamable_content_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_selection_class_init", ((DL_FUNC)S_atk_selection_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_implementor_class_init", ((DL_FUNC)S_atk_implementor_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_image_class_init", ((DL_FUNC)S_atk_image_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_hypertext_class_init", ((DL_FUNC)S_atk_hypertext_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_editable_text_class_init", ((DL_FUNC)S_atk_editable_text_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_component_class_init", ((DL_FUNC)S_atk_component_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_action_class_init", ((DL_FUNC)S_atk_action_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_value_class_init", ((DL_FUNC)S_atk_value_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_text_class_init", ((DL_FUNC)S_atk_text_class_init)); 
R_RegisterCCallable("RGtk2", "S_atk_document_class_init", ((DL_FUNC)S_atk_document_class_init)); 
#if ATK_CHECK_VERSION(1, 12, 1)
R_RegisterCCallable("RGtk2", "S_atk_hyperlink_impl_class_init", ((DL_FUNC)S_atk_hyperlink_impl_class_init));
#endif 
