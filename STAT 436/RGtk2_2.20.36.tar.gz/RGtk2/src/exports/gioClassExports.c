#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gapp_launch_context_class_init", ((DL_FUNC)S_gapp_launch_context_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gcancellable_class_init", ((DL_FUNC)S_gcancellable_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gfilename_completer_class_init", ((DL_FUNC)S_gfilename_completer_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gfile_enumerator_class_init", ((DL_FUNC)S_gfile_enumerator_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gfile_monitor_class_init", ((DL_FUNC)S_gfile_monitor_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_ginput_stream_class_init", ((DL_FUNC)S_ginput_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gfile_input_stream_class_init", ((DL_FUNC)S_gfile_input_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gfilter_input_stream_class_init", ((DL_FUNC)S_gfilter_input_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gbuffered_input_stream_class_init", ((DL_FUNC)S_gbuffered_input_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gdata_input_stream_class_init", ((DL_FUNC)S_gdata_input_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gmemory_input_stream_class_init", ((DL_FUNC)S_gmemory_input_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gmount_operation_class_init", ((DL_FUNC)S_gmount_operation_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_goutput_stream_class_init", ((DL_FUNC)S_goutput_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gmemory_output_stream_class_init", ((DL_FUNC)S_gmemory_output_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gfilter_output_stream_class_init", ((DL_FUNC)S_gfilter_output_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gbuffered_output_stream_class_init", ((DL_FUNC)S_gbuffered_output_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gdata_output_stream_class_init", ((DL_FUNC)S_gdata_output_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gfile_output_stream_class_init", ((DL_FUNC)S_gfile_output_stream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gvfs_class_init", ((DL_FUNC)S_gvfs_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gvolume_monitor_class_init", ((DL_FUNC)S_gvolume_monitor_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gnative_volume_monitor_class_init", ((DL_FUNC)S_gnative_volume_monitor_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gfile_iostream_class_init", ((DL_FUNC)S_gfile_iostream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_ginet_address_class_init", ((DL_FUNC)S_ginet_address_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gnetwork_address_class_init", ((DL_FUNC)S_gnetwork_address_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gnetwork_service_class_init", ((DL_FUNC)S_gnetwork_service_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gresolver_class_init", ((DL_FUNC)S_gresolver_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_class_init", ((DL_FUNC)S_gsocket_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_address_class_init", ((DL_FUNC)S_gsocket_address_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_address_enumerator_class_init", ((DL_FUNC)S_gsocket_address_enumerator_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_client_class_init", ((DL_FUNC)S_gsocket_client_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_connection_class_init", ((DL_FUNC)S_gsocket_connection_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_control_message_class_init", ((DL_FUNC)S_gsocket_control_message_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_listener_class_init", ((DL_FUNC)S_gsocket_listener_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_service_class_init", ((DL_FUNC)S_gsocket_service_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gtcp_connection_class_init", ((DL_FUNC)S_gtcp_connection_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gthreaded_socket_service_class_init", ((DL_FUNC)S_gthreaded_socket_service_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_giostream_class_init", ((DL_FUNC)S_giostream_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_ginet_socket_address_class_init", ((DL_FUNC)S_ginet_socket_address_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gapp_info_class_init", ((DL_FUNC)S_gapp_info_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gasync_result_class_init", ((DL_FUNC)S_gasync_result_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gdrive_class_init", ((DL_FUNC)S_gdrive_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gfile_class_init", ((DL_FUNC)S_gfile_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gicon_class_init", ((DL_FUNC)S_gicon_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gloadable_icon_class_init", ((DL_FUNC)S_gloadable_icon_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gmount_class_init", ((DL_FUNC)S_gmount_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gseekable_class_init", ((DL_FUNC)S_gseekable_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 16, 0)
R_RegisterCCallable("RGtk2", "S_gvolume_class_init", ((DL_FUNC)S_gvolume_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gasync_initable_class_init", ((DL_FUNC)S_gasync_initable_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_ginitable_class_init", ((DL_FUNC)S_ginitable_class_init));
#endif 
#if GIO_CHECK_VERSION(2, 22, 0)
R_RegisterCCallable("RGtk2", "S_gsocket_connectable_class_init", ((DL_FUNC)S_gsocket_connectable_class_init));
#endif 
